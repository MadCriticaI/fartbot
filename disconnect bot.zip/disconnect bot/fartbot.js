const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder } = require('discord.js');

const TOKEN = 'MTM3OTM5ODM0MzIwNTE5NTgwNg.GkE7ot.ITA1qAOzm3rCT7ttFfZRuABIxPE8O33Ng78qMU';
const CLIENT_ID = '1379398343205195806';
const GUILD_ID = '1366591801107939450';

let targetUserId = null;
let mockUserId = null;

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

client.once('ready', async () => {
  console.log(`Logged in as ${client.user.tag}`);

  const commands = [
    new SlashCommandBuilder()
      .setName('target')
      .setDescription('Set the user to auto-disconnect from voice channels')
      .addUserOption(option =>
        option.setName('user')
          .setDescription('The user to target')
          .setRequired(true)
      ),
    new SlashCommandBuilder()
      .setName('mock')
      .setDescription('Set the user to mock their text messages')
      .addUserOption(option =>
        option.setName('user')
          .setDescription('The user to mock')
          .setRequired(true)
      ),
    new SlashCommandBuilder()
      .setName('stoptarget')
      .setDescription('Stop auto-disconnecting any user'),
    new SlashCommandBuilder()
      .setName('stopmock')
      .setDescription('Stop mocking any user'),
  ].map(command => command.toJSON());

  const rest = new REST({ version: '10' }).setToken(TOKEN);

  try {
    await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: commands });
    console.log('Slash commands registered.');
  } catch (error) {
    console.error('Error registering commands:', error);
  }
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;

  if (interaction.commandName === 'target') {
    const user = interaction.options.getUser('user');
    targetUserId = user.id;

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (member?.voice?.channel) {
      try {
        await member.voice.disconnect();
        console.log(`Immediately disconnected ${user.tag} from active voice channel.`);
      } catch (error) {
        console.error(`Failed to disconnect ${user.tag}:`, error);
      }
    }

    await interaction.reply({ content: `✅ Now targeting ${user.tag} for auto-disconnect`, ephemeral: true });
  }
  else if (interaction.commandName === 'mock') {
    const user = interaction.options.getUser('user');
    mockUserId = user.id;
    await interaction.reply({ content: `🤡 Now mocking ${user.tag}'s messages`, ephemeral: true });
  }
  else if (interaction.commandName === 'stoptarget') {
    targetUserId = null;
    await interaction.reply({ content: `🛑 Auto-disconnect targeting disabled.`, ephemeral: true });
  }
  else if (interaction.commandName === 'stopmock') {
    mockUserId = null;
    await interaction.reply({ content: `🛑 Mocking disabled.`, ephemeral: true });
  }
});

client.on('voiceStateUpdate', (oldState, newState) => {
  if (!targetUserId) return;

  if (newState.member.id === targetUserId && newState.channel) {
    newState.disconnect()
      .then(() => console.log(`Disconnected ${newState.member.user.tag}`))
      .catch(console.error);
  }
});

client.on('messageCreate', async (message) => {
  if (!mockUserId) return;
  if (message.author.bot) return;
  if (message.author.id !== mockUserId) return;

  const mocked = message.content
    .split('')
    .map(c => (Math.random() < 0.5 ? c.toUpperCase() : c.toLowerCase()))
    .join('');

  try {
    await message.reply(mocked);
  } catch (error) {
    console.error('Failed to send mock reply:', error);
  }
});

client.login(TOKEN);
